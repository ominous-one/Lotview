import { PlatformDriver, PostJob } from "../types";

const FILL_CHANNEL = "LV_FILL_FACEBOOK";
const FB_MARKETPLACE_PATTERNS = [
  /facebook\.com\/marketplace.*\/create/,
  /facebook\.com\/marketplace\/you\/selling/,
];

async function ensureContentScriptInjected(tabId: number): Promise<void> {
  try {
    await chrome.tabs.sendMessage(tabId, { type: "PING" });
  } catch {
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ["content-facebook.js"],
    });
    await new Promise((r) => setTimeout(r, 200));
  }
}

export const facebookDriver: PlatformDriver = {
  platform: "facebook",
  name: "Facebook Marketplace",
  urlPatterns: [
    "*://*.facebook.com/marketplace/*/create/*",
    "*://*.facebook.com/marketplace/create/*",
    "*://www.facebook.com/marketplace/you/selling*",
  ],

  async fillForm(job: PostJob): Promise<void> {
    return new Promise((resolve, reject) => {
      chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
        const tab = tabs[0];
        if (!tab?.id || !tab.url) {
          reject(new Error("No active tab. Navigate to Facebook Marketplace first."));
          return;
        }

        const isMarketplace = FB_MARKETPLACE_PATTERNS.some((p) => p.test(tab.url || ""));
        if (!isMarketplace) {
          reject(new Error("Please navigate to Facebook Marketplace 'Create new listing' page first."));
          return;
        }

        try {
          await ensureContentScriptInjected(tab.id);
        } catch (err) {
          reject(new Error("Could not inject content script. Please refresh the Facebook page and try again."));
          return;
        }

        chrome.tabs.sendMessage(tab.id, { type: FILL_CHANNEL, payload: job }, (res) => {
          if (chrome.runtime.lastError) {
            const msg = chrome.runtime.lastError.message || "";
            if (msg.includes("Receiving end does not exist")) {
              reject(new Error("Content script not loaded. Please refresh the Facebook page and try again."));
            } else {
              reject(new Error(msg));
            }
            return;
          }
          if (res?.ok) {
            resolve();
          } else {
            reject(new Error(res?.error || "Form fill failed"));
          }
        });
      });
    });
  },
};
