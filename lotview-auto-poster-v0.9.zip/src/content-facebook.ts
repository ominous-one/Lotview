import { PostJob } from "./types";
import { sanitizeFormData, sanitizeNotificationText } from "./sanitize";

const FILL_CHANNEL = "LV_FILL_FACEBOOK";
const MAX_WAIT_FOR_ELEMENT_MS = 10000;
const MUTATION_CHECK_INTERVAL_MS = 200;

interface FillResult {
  success: boolean;
  filledFields: string[];
  missingFields: string[];
  warnings: string[];
}

interface SelectorConfig {
  selectors: string[];
  ariaLabels: string[];
  placeholders: string[];
  nearbyTexts: string[];
  testId?: string;
}

const FIELD_CONFIGS: Record<string, SelectorConfig> = {
  title: {
    selectors: ['input[name="title"]', 'input[data-testid="marketplace-create-title"]'],
    ariaLabels: ["Title", "What are you selling", "Item title"],
    placeholders: ["Title", "What are you selling", "Item title"],
    nearbyTexts: ["title", "what are you selling"],
    testId: "marketplace-create-title",
  },
  price: {
    selectors: ['input[name="price"]', 'input[data-testid="marketplace-create-price"]'],
    ariaLabels: ["Price"],
    placeholders: ["Price", "0"],
    nearbyTexts: ["price"],
    testId: "marketplace-create-price",
  },
  description: {
    selectors: ['textarea[name="description"]', 'textarea[data-testid="marketplace-create-description"]'],
    ariaLabels: ["Description", "Describe your item"],
    placeholders: ["Description", "Describe"],
    nearbyTexts: ["description", "describe"],
    testId: "marketplace-create-description",
  },
  location: {
    selectors: ['input[name="location"]', 'input[data-testid="marketplace-location"]'],
    ariaLabels: ["Location"],
    placeholders: ["Location"],
    nearbyTexts: ["location"],
    testId: "marketplace-location",
  },
};

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function randomDelay(min: number, max: number): number {
  return min + Math.random() * (max - min);
}

function setInputValue(el: HTMLInputElement | HTMLTextAreaElement, value: string): void {
  el.focus();
  el.value = value;
  el.dispatchEvent(new Event("input", { bubbles: true }));
  el.dispatchEvent(new Event("change", { bubbles: true }));
  el.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true }));
  el.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true }));
}

function findInputBySelectors(selectors: string[]): HTMLInputElement | HTMLTextAreaElement | null {
  for (const sel of selectors) {
    try {
      const el = document.querySelector<HTMLInputElement | HTMLTextAreaElement>(sel);
      if (el && el.offsetParent !== null) return el;
    } catch {
      continue;
    }
  }
  return null;
}

function findInputByAriaLabel(labels: string[]): HTMLInputElement | HTMLTextAreaElement | null {
  for (const label of labels) {
    const el = document.querySelector<HTMLInputElement | HTMLTextAreaElement>(
      `input[aria-label*="${label}" i], textarea[aria-label*="${label}" i]`
    );
    if (el && el.offsetParent !== null) return el;
  }
  return null;
}

function findInputByPlaceholder(placeholders: string[]): HTMLInputElement | HTMLTextAreaElement | null {
  for (const ph of placeholders) {
    const el = document.querySelector<HTMLInputElement | HTMLTextAreaElement>(
      `input[placeholder*="${ph}" i], textarea[placeholder*="${ph}" i]`
    );
    if (el && el.offsetParent !== null) return el;
  }
  return null;
}

function findInputByNearbyText(texts: string[]): HTMLInputElement | HTMLTextAreaElement | null {
  for (const text of texts) {
    const spans = document.querySelectorAll("span, label");
    for (const span of spans) {
      if (span.textContent?.toLowerCase().includes(text.toLowerCase())) {
        const container = span.closest("div");
        if (container) {
          const input = container.querySelector<HTMLInputElement | HTMLTextAreaElement>("input, textarea");
          if (input && input.offsetParent !== null) return input;
        }
      }
    }
  }
  return null;
}

function findInputByRole(fieldType: "title" | "price" | "description" | "location"): HTMLInputElement | HTMLTextAreaElement | null {
  const allInputs = document.querySelectorAll<HTMLInputElement | HTMLTextAreaElement>("input:not([type='hidden']):not([type='file']), textarea");
  for (const input of allInputs) {
    if (input.offsetParent === null) continue;
    const name = input.name?.toLowerCase() || "";
    const id = input.id?.toLowerCase() || "";
    const className = input.className?.toLowerCase() || "";
    if (name.includes(fieldType) || id.includes(fieldType) || className.includes(fieldType)) {
      return input;
    }
  }
  return null;
}

function findInput(config: SelectorConfig, fieldType?: string): HTMLInputElement | HTMLTextAreaElement | null {
  let el = findInputBySelectors(config.selectors);
  if (!el) el = findInputByAriaLabel(config.ariaLabels);
  if (!el) el = findInputByPlaceholder(config.placeholders);
  if (!el) el = findInputByNearbyText(config.nearbyTexts);
  if (!el && fieldType) el = findInputByRole(fieldType as "title" | "price" | "description" | "location");
  return el;
}

async function waitForElement(config: SelectorConfig, fieldType?: string): Promise<HTMLInputElement | HTMLTextAreaElement | null> {
  const startTime = Date.now();
  
  while (Date.now() - startTime < MAX_WAIT_FOR_ELEMENT_MS) {
    const el = findInput(config, fieldType);
    if (el) return el;
    
    await new Promise<void>((resolve) => {
      const observer = new MutationObserver(() => {
        const found = findInput(config, fieldType);
        if (found) {
          observer.disconnect();
          resolve();
        }
      });
      
      observer.observe(document.body, { childList: true, subtree: true });
      
      setTimeout(() => {
        observer.disconnect();
        resolve();
      }, MUTATION_CHECK_INTERVAL_MS);
    });
  }
  
  return findInput(config, fieldType);
}

async function setInputWithRetry(
  fieldType: string, 
  value: string, 
  maxRetries: number = 3
): Promise<boolean> {
  const config = FIELD_CONFIGS[fieldType];
  if (!config) return false;
  
  for (let attempt = 0; attempt < maxRetries; attempt++) {
    const el = await waitForElement(config, fieldType);
    
    if (!el) {
      await sleep(500 * (attempt + 1));
      continue;
    }
    
    setInputValue(el, value);
    
    await sleep(100);
    if (el.value === value || el.value.includes(value.substring(0, 20))) {
      return true;
    }
    
    await sleep(300);
  }
  
  return false;
}

const MAX_UPLOAD_IMAGES = 10;
const MAX_IMAGE_SIZE_MB = 10;

async function uploadImages(files: File[]): Promise<{ success: boolean; uploaded: number; skipped: number }> {
  const fileInputs = document.querySelectorAll<HTMLInputElement>('input[type="file"]');
  let input: HTMLInputElement | null = null;
  
  for (const fi of fileInputs) {
    if (fi.accept?.includes("image") || !fi.accept) {
      input = fi;
      break;
    }
  }
  
  if (!input) {
    return { success: false, uploaded: 0, skipped: files.length };
  }

  const validFiles: File[] = [];
  let skipped = 0;

  for (const file of files.slice(0, MAX_UPLOAD_IMAGES)) {
    if (file.size > MAX_IMAGE_SIZE_MB * 1024 * 1024) {
      skipped++;
      continue;
    }
    validFiles.push(file);
  }

  if (files.length > MAX_UPLOAD_IMAGES) {
    skipped += files.length - MAX_UPLOAD_IMAGES;
  }

  if (validFiles.length === 0) {
    return { success: false, uploaded: 0, skipped };
  }
  
  const dataTransfer = new DataTransfer();
  validFiles.forEach((f) => dataTransfer.items.add(f));
  input.files = dataTransfer.files;
  input.dispatchEvent(new Event("change", { bubbles: true }));
  
  return { success: true, uploaded: validFiles.length, skipped };
}

async function fillFacebook(job: PostJob): Promise<FillResult> {
  const { formData: rawFormData, images } = job;
  const formData = sanitizeFormData(rawFormData);
  const filledFields: string[] = [];
  const missingFields: string[] = [];
  const warnings: string[] = [];

  const titleValue = typeof formData.title === "string" ? formData.title : "";
  const titleFilled = await setInputWithRetry("title", titleValue);
  if (titleFilled) {
    filledFields.push("title");
  } else {
    missingFields.push("title");
  }
  await sleep(randomDelay(200, 400));

  if (formData.price !== null && formData.price !== undefined && formData.price !== "") {
    const priceValue = String(formData.price);
    const priceFilled = await setInputWithRetry("price", priceValue);
    if (priceFilled) {
      filledFields.push("price");
    } else {
      missingFields.push("price");
    }
    await sleep(randomDelay(150, 300));
  }

  const descValue = typeof formData.description === "string" ? formData.description : "";
  const descFilled = await setInputWithRetry("description", descValue);
  if (descFilled) {
    filledFields.push("description");
  } else {
    missingFields.push("description");
  }
  await sleep(randomDelay(300, 500));

  if (formData.location && typeof formData.location === "string") {
    const locFilled = await setInputWithRetry("location", formData.location);
    if (locFilled) {
      filledFields.push("location");
    } else {
      warnings.push("Location field not found");
    }
    await sleep(randomDelay(300, 500));
  }

  if (images && images.length > 0) {
    const uploadResult = await uploadImages(images);
    if (uploadResult.success) {
      filledFields.push(`images (${uploadResult.uploaded})`);
      if (uploadResult.skipped > 0) {
        warnings.push(`${uploadResult.skipped} images skipped (size/count limit)`);
      }
    } else {
      warnings.push("Photo upload field not found");
    }
    await sleep(randomDelay(800, 1500));
  }

  const requiredFields = ["title", "description"];
  const missingRequired = requiredFields.filter((f) => missingFields.includes(f));
  
  return {
    success: missingRequired.length === 0,
    filledFields,
    missingFields,
    warnings,
  };
}

function showNotification(message: string, type: "success" | "error" | "info"): void {
  const existing = document.getElementById("lv-notification");
  if (existing) existing.remove();
  
  const sanitizedMessage = sanitizeNotificationText(message);
  
  const div = document.createElement("div");
  div.id = "lv-notification";
  div.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    padding: 16px 24px;
    border-radius: 8px;
    color: white;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    font-size: 14px;
    z-index: 999999;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    max-width: 350px;
    background: ${type === "success" ? "#22c55e" : type === "error" ? "#ef4444" : "#3b82f6"};
  `;
  div.textContent = sanitizedMessage;
  document.body.appendChild(div);
  
  setTimeout(() => div.remove(), 6000);
}

function cleanupNotification(): void {
  const existing = document.getElementById("lv-notification");
  if (existing) existing.remove();
}

window.addEventListener("beforeunload", cleanupNotification);
document.addEventListener("visibilitychange", () => {
  if (document.visibilityState === "hidden") {
    cleanupNotification();
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "PING") {
    sendResponse({ ok: true });
    return true;
  }

  if (message.type !== FILL_CHANNEL) {
    return false;
  }

  (async () => {
    try {
      showNotification("Filling form...", "info");
      const job: PostJob = message.payload;
      const result = await fillFacebook(job);
      
      if (!result.success) {
        const errorMsg = `Form fill failed: Could not find ${result.missingFields.join(", ")} field(s). Facebook may have changed their page layout.`;
        showNotification(errorMsg, "error");
        sendResponse({ ok: false, error: errorMsg, details: result });
        return;
      }
      
      let successMsg = `Form filled! Completed: ${result.filledFields.join(", ")}.`;
      if (result.warnings.length > 0) {
        successMsg += ` Note: ${result.warnings.join("; ")}`;
      }
      successMsg += " Review and click Publish.";
      
      showNotification(successMsg, "success");
      sendResponse({ ok: true, details: result });
    } catch (err: unknown) {
      const error = err instanceof Error ? err.message : "Fill failed";
      showNotification(`Error: ${error}`, "error");
      sendResponse({ ok: false, error });
    }
  })();
  
  return true;
});
