let selectedVehicle = null;
let allVehicles = [];
let isOnMarketplace = false;

document.addEventListener('DOMContentLoaded', async () => {
  await checkCurrentTab();
  await checkAuth();
  setupEventListeners();
});

async function checkCurrentTab() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    isOnMarketplace = tab?.url?.includes('facebook.com/marketplace/create');
  } catch (e) {
    console.error('Error checking tab:', e);
  }
}

async function checkAuth() {
  const response = await sendMessage({ action: 'getAuthToken' });
  
  if (response?.token && response?.user) {
    showMainView(response.user);
    loadVehicles();
  } else {
    showLoginView();
    // Pre-fill server URL if previously set
    const stored = await chrome.storage.sync.get(['apiBaseUrl']);
    if (stored.apiBaseUrl) {
      document.getElementById('server-url').value = stored.apiBaseUrl;
    }
  }
}

function showLoginView() {
  document.getElementById('login-view').style.display = 'block';
  document.getElementById('main-view').style.display = 'none';
  document.getElementById('not-on-marketplace').style.display = 'none';
}

function showMainView(user) {
  document.getElementById('login-view').style.display = 'none';
  document.getElementById('main-view').style.display = 'block';
  document.getElementById('not-on-marketplace').style.display = 'none';
  document.getElementById('user-name').textContent = `Welcome, ${user.firstName || user.email}`;
}

function setupEventListeners() {
  const loginForm = document.getElementById('login-form');
  loginForm.addEventListener('submit', handleLogin);

  const logoutBtn = document.getElementById('logout-btn');
  logoutBtn.addEventListener('click', handleLogout);

  const searchInput = document.getElementById('vehicle-search');
  let searchTimeout;
  searchInput.addEventListener('input', (e) => {
    clearTimeout(searchTimeout);
    searchTimeout = setTimeout(() => filterVehicles(e.target.value), 300);
  });

  const fillFormBtn = document.getElementById('fill-form-btn');
  fillFormBtn.addEventListener('click', fillMarketplaceForm);

  const clearSelectionBtn = document.getElementById('clear-selection-btn');
  clearSelectionBtn.addEventListener('click', clearSelection);
}

async function handleLogin(e) {
  e.preventDefault();
  
  const serverUrl = document.getElementById('server-url').value.replace(/\/$/, ''); // Remove trailing slash
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;
  const errorEl = document.getElementById('login-error');
  const btn = document.getElementById('login-btn');
  
  errorEl.classList.remove('show');
  btn.disabled = true;
  btn.querySelector('.btn-text').style.display = 'none';
  btn.querySelector('.btn-loading').style.display = 'inline';

  try {
    const response = await sendMessage({ action: 'login', email, password, serverUrl });
    
    if (response.success) {
      showMainView(response.user);
      loadVehicles();
    } else {
      errorEl.textContent = response.error || 'Login failed';
      errorEl.classList.add('show');
    }
  } catch (error) {
    errorEl.textContent = error.message || 'Login failed';
    errorEl.classList.add('show');
  } finally {
    btn.disabled = false;
    btn.querySelector('.btn-text').style.display = 'inline';
    btn.querySelector('.btn-loading').style.display = 'none';
  }
}

async function handleLogout() {
  await sendMessage({ action: 'logout' });
  showLoginView();
  selectedVehicle = null;
  allVehicles = [];
}

async function loadVehicles() {
  const listEl = document.getElementById('vehicle-list');
  listEl.innerHTML = '<div class="loading">Loading vehicles...</div>';

  try {
    const response = await sendMessage({ action: 'fetchVehicles' });
    
    if (response.success) {
      allVehicles = response.vehicles;
      renderVehicleList(allVehicles);
    } else {
      listEl.innerHTML = `<div class="empty-state">${response.error || 'Failed to load vehicles'}</div>`;
    }
  } catch (error) {
    listEl.innerHTML = `<div class="empty-state">${error.message || 'Failed to load vehicles'}</div>`;
  }
}

function filterVehicles(query) {
  if (!query.trim()) {
    renderVehicleList(allVehicles);
    return;
  }

  const lowerQuery = query.toLowerCase();
  const filtered = allVehicles.filter(v => {
    const title = `${v.year} ${v.make} ${v.model}`.toLowerCase();
    const stockNum = (v.stockNumber || '').toLowerCase();
    return title.includes(lowerQuery) || stockNum.includes(lowerQuery);
  });
  
  renderVehicleList(filtered);
}

function renderVehicleList(vehicles) {
  const listEl = document.getElementById('vehicle-list');
  
  if (vehicles.length === 0) {
    listEl.innerHTML = '<div class="empty-state">No vehicles found</div>';
    return;
  }

  listEl.innerHTML = vehicles.map(v => {
    const title = `${v.year} ${v.make} ${v.model}`;
    const price = v.price ? `$${v.price.toLocaleString()}` : 'Price TBD';
    const image = v.images?.[0] || v.imageUrl || '';
    const isSelected = selectedVehicle?.id === v.id;
    const postedLabel = v.postedToMarketplace ? 
      '<span class="vehicle-item-posted">Already Posted</span>' : '';

    return `
      <div class="vehicle-item ${isSelected ? 'selected' : ''}" data-id="${v.id}">
        <img src="${image}" alt="${title}" onerror="this.src='data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 75%22><rect fill=%22%23e2e8f0%22 width=%22100%22 height=%2275%22/><text x=%2250%22 y=%2240%22 text-anchor=%22middle%22 fill=%22%2394a3b8%22 font-size=%2212%22>No Image</text></svg>'">
        <div class="vehicle-item-info">
          <div class="vehicle-item-title">${title}</div>
          <div class="vehicle-item-details">
            <span>${v.mileage ? v.mileage.toLocaleString() + ' km' : ''}</span>
            <span>${v.stockNumber || ''}</span>
          </div>
          <div class="vehicle-item-price">${price}</div>
          ${postedLabel}
        </div>
      </div>
    `;
  }).join('');

  listEl.querySelectorAll('.vehicle-item').forEach(item => {
    item.addEventListener('click', () => selectVehicle(parseInt(item.dataset.id)));
  });
}

function selectVehicle(vehicleId) {
  selectedVehicle = allVehicles.find(v => v.id === vehicleId);
  
  if (!selectedVehicle) return;

  document.querySelectorAll('.vehicle-item').forEach(el => {
    el.classList.toggle('selected', parseInt(el.dataset.id) === vehicleId);
  });

  const previewEl = document.getElementById('selected-vehicle');
  const title = `${selectedVehicle.year} ${selectedVehicle.make} ${selectedVehicle.model}`;
  const price = selectedVehicle.price ? `$${selectedVehicle.price.toLocaleString()}` : 'Price TBD';
  const image = selectedVehicle.images?.[0] || selectedVehicle.imageUrl || '';

  document.getElementById('preview-image').src = image;
  document.getElementById('preview-title').textContent = title;
  document.getElementById('preview-price').textContent = price;
  previewEl.style.display = 'block';
}

function clearSelection() {
  selectedVehicle = null;
  document.querySelectorAll('.vehicle-item').forEach(el => {
    el.classList.remove('selected');
  });
  document.getElementById('selected-vehicle').style.display = 'none';
}

async function fillMarketplaceForm() {
  if (!selectedVehicle) return;

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  
  if (!tab?.url?.includes('facebook.com/marketplace')) {
    if (confirm('You need to be on Facebook Marketplace to fill the form. Open Marketplace now?')) {
      chrome.tabs.create({ url: 'https://www.facebook.com/marketplace/create/vehicle' });
    }
    return;
  }

  try {
    await chrome.tabs.sendMessage(tab.id, {
      action: 'fillForm',
      vehicle: selectedVehicle
    });

    await sendMessage({
      action: 'markAsPosted',
      vehicleId: selectedVehicle.id,
      platform: 'facebook_marketplace'
    });

    window.close();
  } catch (error) {
    console.error('Error filling form:', error);
    alert('Error filling form. Make sure you are on the Facebook Marketplace listing page.');
  }
}

function sendMessage(message) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(message, resolve);
  });
}
