import puppeteer from 'puppeteer-extra';
import StealthPlugin from 'puppeteer-extra-plugin-stealth';
import { execSync } from 'child_process';
import { cookieStore } from './cloudflare-bypass/cookie-store';
import { proxyManager } from './cloudflare-bypass/proxy-manager';
import { generateRandomFingerprint, applyFingerprint, randomDelay, isCloudflareChallenge, humanLikeScroll } from './cloudflare-bypass/browser-utils';
import {
  extractVehicleImages,
  validateImages,
  calculateImageQualityRating,
  calculateDataQualityScore,
  type ExtractedImage
} from './precision-image-extractor';

// Apply stealth plugin to evade bot detection
puppeteer.use(StealthPlugin());

const DEALER_CONFIGS = [
  {
    name: 'Olympic Hyundai Vancouver',
    url: 'https://www.olympichyundaivancouver.com/vehicles/used/?st=price,desc&view=grid&sc=used',
    domain: 'olympichyundaivancouver.com',
    dealershipId: 1,
    location: 'Vancouver'
  },
  // TEMPORARILY DISABLED FOR TESTING - Enable after Olympic Hyundai works perfectly
  // {
  //   name: 'Boundary Hyundai',
  //   url: 'https://www.boundaryhyundai.com/vehicles/used/?st=price,desc&view=grid&sc=used',
  //   domain: 'boundaryhyundai.com',
  //   dealershipId: 2,
  //   location: 'Burnaby'
  // },
  // {
  //   name: 'Kia Vancouver',
  //   url: 'https://www.kiavancouver.com/vehicles/used/?st=year,desc&view=grid&sc=used',
  //   domain: 'kiavancouver.com',
  //   dealershipId: 3,
  //   location: 'Vancouver'
  // }
];

export interface DealerVehicleListing {
  vin: string | null;
  year: number;
  make: string;
  model: string;
  trim: string;
  odometer: number | null;
  price: number | null;
  images: string[];
  description: string;
  badges: string[];
  type: string;
  stockNumber: string | null;
  vdpUrl: string;
  dealershipId: number;
  dealershipName: string;
  location: string;
  imageQuality: 'excellent' | 'good' | 'fair' | 'poor';
  dataQualityScore: number;
}

function parsePrice(priceText: string): number | null {
  const priceMatch = priceText.match(/\$?\s*([0-9,]+)/);
  if (priceMatch) {
    const price = parseInt(priceMatch[1].replace(/,/g, ''));
    if (price >= 1000 && price <= 500000) {
      return price;
    }
  }
  return null;
}

function parseOdometer(odoText: string): number | null {
  const odoMatch = odoText.match(/([0-9,]+)\s*(km|kilometers?)/i);
  if (odoMatch) {
    return parseInt(odoMatch[1].replace(/,/g, ''));
  }
  return null;
}

function parseYear(text: string): number | null {
  const yearMatch = text.match(/\b(20\d{2})\b/);
  if (yearMatch) {
    return parseInt(yearMatch[1]);
  }
  return null;
}

// Helper function to determine body type from text
function determineBodyType(text: string): string {
  const lowerText = text.toLowerCase();
  
  if (lowerText.includes('sedan')) return 'Sedan';
  if (lowerText.includes('suv') || lowerText.includes('sport utility')) return 'SUV';
  if (lowerText.includes('truck') || lowerText.includes('pickup')) return 'Truck';
  if (lowerText.includes('hatchback')) return 'Hatchback';
  if (lowerText.includes('coupe') || lowerText.includes('convertible')) return 'Coupe';
  if (lowerText.includes('wagon')) return 'Wagon';
  if (lowerText.includes('minivan') || lowerText.includes('van')) return 'Minivan';
  
  return 'SUV'; // Default
}

// Helper function to detect badges from text
function detectBadges(text: string): string[] {
  const badges: string[] = [];
  const lowerText = text.toLowerCase();
  
  if (/\b(one owner|1 owner|single owner)\b/.test(lowerText)) {
    badges.push('One Owner');
  }
  if (/\b(no accidents?|accident free|clean history|accident-free)\b/.test(lowerText)) {
    badges.push('No Accidents');
  }
  if (/\b(clean title|clear title)\b/.test(lowerText)) {
    badges.push('Clean Title');
  }
  if (/\b(certified|cpo|certified pre-owned)\b/.test(lowerText)) {
    badges.push('Certified Pre-Owned');
  }
  if (/\b(low km|low kilometers|low mileage|low km's)\b/.test(lowerText)) {
    badges.push('Low Kilometers');
  }
  
  return badges;
}

interface VehicleDetailData {
  vin: string | null;
  price: number | null;
  odometer: number | null;
  images: string[];
  trim: string;
  description: string;
  badges: string[];
  type: string;
  stockNumber: string | null;
  imageQuality: 'excellent' | 'good' | 'fair' | 'poor';
  dataQualityScore: number;
}

// Scrape VDP using an existing page (reuses page instead of creating new ones)
async function scrapeVehicleDetailPage(page: any, vdpUrl: string, retries = 2): Promise<VehicleDetailData> {
  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      // Navigate to VDP using existing page
      await page.goto(vdpUrl, { waitUntil: 'domcontentloaded', timeout: 25000 });
      
      // Wait for the page to be fully interactive
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Check for Cloudflare challenge on VDP page
      const isChallenged = await isCloudflareChallenge(page);
      if (isChallenged) {
        console.log('    ⚠ Cloudflare challenge on VDP, waiting...');
        // Wait for challenge to resolve
        for (let i = 0; i < 15; i++) {
          await new Promise(resolve => setTimeout(resolve, 2000));
          if (!(await isCloudflareChallenge(page))) {
            console.log('    ✓ VDP challenge resolved');
            break;
          }
        }
      }
      
      // Wait for dynamic content to render
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Debug: Log that we're about to extract data
      const pageUrl = await page.url();
      console.log(`    → VDP loaded: ${pageUrl}`);
      
      // Click through gallery carousel to load all images (Alpine.js lazy loading)
      try {
        // Click gallery next button multiple times to load all images
        const nextButtonSelectors = [
          '.photo-gallery__arrow--next',
          '.mobile-slider__arrow--next', 
          '[class*="gallery"] [class*="next"]',
          '[class*="slider"] [class*="next"]',
          '.swiper-button-next',
          '.slick-next'
        ];
        
        for (const selector of nextButtonSelectors) {
          const nextBtn = await page.$(selector);
          if (nextBtn) {
            // Click through 50 images to ensure all are loaded
            // IMPROVED: 150ms delay (was 100ms) + visibility check before each click
            for (let clickCount = 0; clickCount < 50; clickCount++) {
              try {
                // Check if button is still visible and clickable before clicking
                const isClickable = await page.evaluate((sel: string) => {
                  const btn = document.querySelector(sel);
                  if (!btn) return false;
                  const style = window.getComputedStyle(btn);
                  return style.display !== 'none' && 
                         style.visibility !== 'hidden' && 
                         !btn.hasAttribute('disabled');
                }, selector);
                
                if (!isClickable) break;
                
                await nextBtn.click();
                await new Promise(resolve => setTimeout(resolve, 150)); // Increased from 100ms to 150ms
              } catch (e) {
                break; // Button may become disabled
              }
            }
            break; // Found and clicked a gallery button
          }
        }
      } catch (galleryErr) {
        // Gallery clicking is optional, continue with extraction
      }
      
      // Wait a moment for images to load after gallery navigation
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // Use page.evaluate with a string to prevent ESBuild transformation
      const data = await page.evaluate(`(function() {
        var pageText = document.body.textContent || '';
        
        function isPaymentContext(element) {
          var paymentKeywords = /payment|weekly|bi-?weekly|monthly|calculator|financing|finance|per\\s+month|\\/mo/i;
          var elementText = element.textContent || '';
          if (paymentKeywords.test(elementText)) return true;
          var elementClass = element.getAttribute('class') || '';
          var elementId = element.getAttribute('id') || '';
          if (paymentKeywords.test(elementClass) || paymentKeywords.test(elementId)) return true;
          var parent = element.parentElement;
          if (parent) {
            var parentClass = parent.getAttribute('class') || '';
            var parentId = parent.getAttribute('id') || '';
            if (paymentKeywords.test(parentClass) || paymentKeywords.test(parentId)) return true;
          }
          return false;
        }
        
        var pageTitle = document.title || 'No title';
        var bodyLength = pageText.length;
        var priceElExists = document.querySelector('.vehicle-price') ? 'yes' : 'no';
        var allImgs = document.querySelectorAll('img').length;
        var allPriceElements = document.querySelectorAll('[class*="price"]').length;
        
        // Extract VIN (no TypeScript annotations)
        var vin = null;
        var vinMatch = pageText.match(/VIN[:\\s]*([A-HJ-NPR-Z0-9]{17})/i);
        if (vinMatch) {
          vin = vinMatch[1].toUpperCase();
        }
        
        // Extract Stock Number
        var stockNumber = null;
        var stockMatch = pageText.match(/stock[#\\s:]*([A-Z0-9-]+)/i);
        if (stockMatch) {
          stockNumber = stockMatch[1];
        }
        
        // Extract price - target the actual selling price with high confidence
        var price = null;
        var priceConfidence = 'low';
        var priceSource = 'none';
        
        // Strategy 1: Target authoritative DOM nodes with dealer-specific selectors
        // NOTE: Avoid overly generic selectors like [id*="price"] that match financing widgets
        // IMPORTANT: Order matters - more specific selectors first
        var authoritativePriceSelectors = [
          // Olympic Hyundai Vancouver specific - the main selling price
          '.price-block__price--primary',
          '.price-block__price',
          '.main-price',
          // Standard dealer website patterns
          '[data-field="price"]',
          '[data-field="sellingPrice"]',
          '[data-price]',
          '[itemprop="price"]',
          '.vehicle-price__price',
          '.vehicle-price',
          '.dealer-price',
          '.selling-price',
          '.final-price',
          '.sale-price',
          '#vehicle-price',
          '#selling-price',
          '#dealer-price'
          // Deliberately excluding generic [id*="price"] and [class*="sale-price"] to avoid matching financing calculators
        ];
        
        for (var pi = 0; pi < authoritativePriceSelectors.length; pi++) {
          var priceSelector = authoritativePriceSelectors[pi];
          var priceEl = document.querySelector(priceSelector);
          if (priceEl) {
            // CRITICAL: Use payment context helper to reject payment widgets
            if (!isPaymentContext(priceEl)) {
              var priceText = priceEl.textContent || priceEl.getAttribute('data-value') || priceEl.getAttribute('data-price') || '';
              var priceMatchResult = priceText.match(/\\$?\\s*([0-9,]+)/);
              if (priceMatchResult) {
                var priceVal = parseInt(priceMatchResult[1].replace(/,/g, ''));
                // Realistic minimum: $1000 (excludes payment amounts like $399)
                if (priceVal >= 1000 && priceVal <= 500000) {
                  price = priceVal;
                  priceConfidence = 'high';
                  priceSource = priceSelector;
                  break; // Use first valid CASH price from authoritative selector
                }
                // Note: Values below $1000 are ignored as likely payment amounts
              }
            }
          }
        }
        
        // Strategy 2: Scoped regex with label anchoring (high confidence)
        if (!price) {
          var labeledPricePatterns = [
            /(?:Sale|Selling|Asking|Dealer|Final|Internet)\\s*Price[:\\s]*\\$?\\s*([0-9,]+)/i,
            /Price[:\\s]*\\$?\\s*([0-9,]+)(?!\\s*(?:weekly|monthly|payment))/i,
            /\\$\\s*([0-9,]+)\\s*(?:CAD|CDN|Canadian)?(?!\\s*(?:weekly|monthly|payment|per))/i
          ];
          
          for (var lpi = 0; lpi < labeledPricePatterns.length; lpi++) {
            var pattern = labeledPricePatterns[lpi];
            var labeledMatch = pageText.match(pattern);
            if (labeledMatch) {
              var labeledVal = parseInt(labeledMatch[1].replace(/,/g, ''));
              // Realistic minimum: $1000 (excludes typical payment amounts)
              if (labeledVal >= 1000 && labeledVal <= 500000) {
                price = labeledVal;
                priceConfidence = 'medium';
                priceSource = 'labeled-pattern';
                break;
              }
              // Note: Values below $1000 are ignored as likely payment amounts
            }
          }
        }
        
        // Strategy 3: Last resort - scan all prices, use median (avoid both payments and MSRP)
        // NOTE: This is unreliable and may be removed in future
        if (!price) {
          var priceRegex = /\\$\\s*([0-9,]+)(?!\\s*(?:weekly|bi-?weekly|monthly|per\\s+month|\\/mo|payment))/gi;
          var priceMatch2;
          var prices = [];
          
          while ((priceMatch2 = priceRegex.exec(pageText)) !== null) {
            var val = parseInt(priceMatch2[1].replace(/,/g, ''));
            // Minimum $2000 for fallback strategy (more conservative but still captures low-end inventory)
            if (val >= 2000 && val <= 500000) {
              prices.push(val);
            }
          }
          
          // Use MEDIAN price (more robust than min/max)
          if (prices.length >= 2) {
            prices.sort(function(a, b) { return a - b; });
            var mid = Math.floor(prices.length / 2);
            price = prices.length % 2 === 0 ? prices[mid - 1] : prices[mid];
            priceConfidence = 'low';
          } else if (prices.length === 1) {
            price = prices[0];
            priceConfidence = 'low';
          }
          // Note: Low confidence prices are still used but should be validated
        }
        
        // Extract odometer
        var odometer = null;
        var odoMatch = pageText.match(/([0-9,]+)\\s*(km|kilometers?)/i);
        if (odoMatch) {
          var odoVal = parseInt(odoMatch[1].replace(/,/g, ''));
          if (odoVal > 0 && odoVal < 500000) {
            odometer = odoVal;
          }
        }
        
        // Extract trim from title/heading
        var trim = 'Base';
        var h1El = document.querySelector('h1');
        if (h1El) {
          var titleText = h1El.textContent || '';
          // Try to extract trim from title (usually after model name)
          var trimMatch = titleText.match(/(?:\\d{4}\\s+[A-Za-z-]+\\s+[A-Za-z0-9-]+\\s+)([A-Za-z0-9\\s]+)/i);
          if (trimMatch && trimMatch[1]) {
            trim = trimMatch[1].trim();
          }
        }
        
        // Extract description
        var description = '';
        var descriptionSelectors = [
          '[class*="description"]',
          '[class*="details"]',
          '[class*="comments"]',
          'p[class*="text"]',
          '.vehicle-description',
          '#description'
        ];
        
        for (var di = 0; di < descriptionSelectors.length; di++) {
          var descSelector = descriptionSelectors[di];
          var descElement = document.querySelector(descSelector);
          if (descElement && descElement.textContent && descElement.textContent.length > 50) {
            description = descElement.textContent.trim();
            break;
          }
        }
        
        // If no description found, create a basic one
        if (!description) {
          description = 'Used vehicle. Contact dealer for more information.';
        }
        
        // Extract images - FOCUSED ON VEHICLE PHOTO CDN DOMAINS
        var images = [];
        var processedUrls = {};
        var debugImgInfo = [];
        
        // TRUSTED VEHICLE PHOTO CDN DOMAINS - these contain actual car photos
        // EXPANDED from refactored scraper to include HomeNet and more CDNs
        var trustedPhotoCDNs = [
          'autotradercdn.ca/photos',        // AutoTrader CDN - main vehicle photos
          'photos.autotrader.ca',           // AutoTrader alternate
          'photomanager',                    // Photo manager services
          '/vehicles/',                      // Dealer's own vehicle photos
          'cargurus.com/images/forsale',    // CarGurus vehicle images
          'ddclstatic.com',                 // DDC vehicle images
          'dealercdn.com',                  // Dealer CDN
          'dealerinspire.com/vehicles',     // DI vehicle images
          'photos.dealer.com',              // Dealer.com photos
          'gdealer.com',                    // GDealer images
          'evoxcdn.com',                    // Evox images
          'ws-assets.dealercom.net',        // DealerSocket images
          'homenetiol.com',                 // HomeNet inventory images (MAJOR PROVIDER)
          'homenet-inc.com',                // HomeNet alternate domain
          'cdnmedia.endeavorsuite.com',     // Endeavor/PBS suite images
          'images.foxdealer.com',           // Fox dealer images
          'spincar.com',                    // SpinCar 360 photos
          '360.spincar.com',                // SpinCar 360 alternate
          'izmostock.com',                  // Stock photos for new vehicles
          'lotstalk.net',                   // LotsTalk inventory images
          'vauto.com'                       // vAuto images
        ];
        
        // BLOCKED PROMOTIONAL DOMAINS - these are banners/site images
        var blockedPatterns = [
          'cdn-convertus.com/uploads/sites/', // Site promotional images
          'form-',                             // Form background images  
          'bg-',                               // Background images
          '-bg',                               // Background suffix
          'Welcome-background',                // Welcome banners
          'Get-Approved',                      // Promotional
          'Pictogram',                         // Icons
          'quote-',                            // Quote icons
          '-dark.png',                         // Icon variants
          '-light.png',                        // Icon variants
          'Home-Delivery',                     // Promotional banner
          'Car-Buying',                        // Promotional banner
          'hassle'                             // Promotional text
        ];
        
        // Helper function to check if URL is from a trusted vehicle photo CDN
        function isVehiclePhotoCDN(src) {
          if (!src || src.length < 10) return false;
          var lower = src.toLowerCase();
          
          // First check if it's blocked
          for (var bi = 0; bi < blockedPatterns.length; bi++) {
            if (lower.indexOf(blockedPatterns[bi].toLowerCase()) !== -1) {
              return false;
            }
          }
          
          // Check if from trusted CDN
          for (var ci = 0; ci < trustedPhotoCDNs.length; ci++) {
            if (lower.indexOf(trustedPhotoCDNs[ci].toLowerCase()) !== -1) {
              return true;
            }
          }
          
          return false;
        }
        
        // Helper function to normalize URL
        function normalizeUrl(src) {
          if (src.indexOf('//') === 0) {
            return 'https:' + src;
          } else if (src.indexOf('/') === 0) {
            return window.location.origin + src;
          }
          return src;
        }
        
        // Helper function to upgrade image URLs to higher resolution
        // Tries to get 2048px instead of 1024px where supported
        function upgradeImageResolution(url) {
          var upgraded = url;
          
          // AutoTrader CDN - upgrade to higher resolution
          if (url.indexOf('autotradercdn.ca') !== -1) {
            // Replace common size patterns with larger ones
            upgraded = upgraded.replace(/-1024x786\\./, '-2048x1536.');
            upgraded = upgraded.replace(/-640x480\\./, '-2048x1536.');
            upgraded = upgraded.replace(/w=\\d+/, 'w=2048');
            upgraded = upgraded.replace(/width=\\d+/, 'width=2048');
            upgraded = upgraded.replace(/h=\\d+/, 'h=1536');
            upgraded = upgraded.replace(/height=\\d+/, 'height=1536');
          }
          
          // CarGurus - upgrade to max quality
          if (url.indexOf('cargurus.com/images/forsale') !== -1) {
            var baseUrl = url.split('?')[0];
            upgraded = baseUrl + '?io=true&width=2048&height=1536&fit=bounds&format=jpg&auto=webp';
          }
          
          // DealerInspire - use large version
          if (url.indexOf('dealerinspire.com') !== -1) {
            upgraded = upgraded.replace('/thumb/', '/large/');
            upgraded = upgraded.replace('/small/', '/large/');
            upgraded = upgraded.replace('/medium/', '/large/');
          }
          
          // HomeNet - try to get larger images
          if (url.indexOf('homenetiol.com') !== -1 || url.indexOf('homenet-inc.com') !== -1) {
            upgraded = upgraded.replace(/sz=\\d+/, 'sz=2048');
            upgraded = upgraded.replace(/size=\\d+/, 'size=2048');
          }
          
          return upgraded;
        }
        
        // STRATEGY 1: Look ONLY in gallery/slider containers for vehicle photos
        var galleryContainers = document.querySelectorAll('.photo-gallery, .mobile-slider, .vehicle-gallery, .gallery-container, [class*="vehicle-photo"], [class*="main-image"]');
        debugImgInfo.push('Gallery containers: ' + galleryContainers.length);
        
        // Collect all img elements from gallery containers
        var galleryImgs = [];
        for (var gc = 0; gc < galleryContainers.length; gc++) {
          var containerImgs = galleryContainers[gc].querySelectorAll('img');
          for (var gci = 0; gci < containerImgs.length; gci++) {
            galleryImgs.push(containerImgs[gci]);
          }
        }
        
        debugImgInfo.push('Gallery imgs: ' + galleryImgs.length);
        
        // Extract from gallery images first (priority)
        for (var i = 0; i < galleryImgs.length; i++) {
          var img = galleryImgs[i];
          // Use .src property for dynamic content (not getAttribute)
          // EXPANDED: Check 8+ lazy-load attributes to capture more images
          var possibleSrcs = [
            img.src,                           // Current loaded source
            img.currentSrc,                    // What browser actually displays
            img.getAttribute('data-src'),
            img.getAttribute('data-lazy-src'),
            img.getAttribute('data-original'),
            img.getAttribute('data-image'),
            img.getAttribute('data-full-size'),
            img.getAttribute('data-large-src'),  // Large version
            img.getAttribute('data-zoom-image'), // Zoom version (usually high-res)
            img.getAttribute('data-srcset'),     // Responsive srcset
            img.getAttribute('srcset')           // Standard srcset
          ];
          
          for (var ps = 0; ps < possibleSrcs.length; ps++) {
            var src = possibleSrcs[ps];
            if (src && src.length > 10) {
              src = normalizeUrl(src);
              if (src.indexOf('http') === 0 && !processedUrls[src]) {
                // STRICT: Only allow images from trusted CDN domains
                if (isVehiclePhotoCDN(src)) {
                  // UPGRADE: Try to get higher resolution version
                  var upgradedSrc = upgradeImageResolution(src);
                  processedUrls[src] = true;
                  processedUrls[upgradedSrc] = true; // Prevent duplicates with upgraded URL
                  images.push(upgradedSrc);
                }
              }
            }
          }
        }
        
        debugImgInfo.push('After gallery: ' + images.length);
        
        // STRATEGY 2: Look for AutoTrader CDN photos anywhere on page
        var allImgElements = document.querySelectorAll('img');
        for (var ai = 0; ai < allImgElements.length; ai++) {
          var allImg = allImgElements[ai];
          var src = allImg.src || allImg.currentSrc || '';
          if (src && isVehiclePhotoCDN(src)) {
            src = normalizeUrl(src);
            if (src.indexOf('http') === 0 && !processedUrls[src]) {
              // UPGRADE: Try to get higher resolution version
              var upgradedSrc = upgradeImageResolution(src);
              processedUrls[src] = true;
              processedUrls[upgradedSrc] = true;
              images.push(upgradedSrc);
            }
          }
        }
        
        debugImgInfo.push('After CDN scan: ' + images.length);
        
        // STRATEGY 3: Look for background images ONLY from trusted CDNs
        var elementsWithBg = document.querySelectorAll('[style*="background"]');
        for (var bi2 = 0; bi2 < elementsWithBg.length; bi2++) {
          var el = elementsWithBg[bi2];
          var style = el.getAttribute('style') || '';
          var bgMatch = style.match(/url\\s*\\(\\s*['"]?([^'"\\)]+)['"]?\\s*\\)/i);
          if (bgMatch && bgMatch[1]) {
            var bgSrc = bgMatch[1];
            bgSrc = normalizeUrl(bgSrc);
            if (bgSrc.indexOf('http') === 0 && isVehiclePhotoCDN(bgSrc) && !processedUrls[bgSrc]) {
              // UPGRADE: Try to get higher resolution version
              var upgradedBgSrc = upgradeImageResolution(bgSrc);
              processedUrls[bgSrc] = true;
              processedUrls[upgradedBgSrc] = true;
              images.push(upgradedBgSrc);
            }
          }
        }
        
        debugImgInfo.push('After bg (CDN only): ' + images.length);
        
        return {
          vin: vin,
          price: price,
          odometer: odometer,
          images: images,
          trim: trim,
          description: description,
          stockNumber: stockNumber,
          pageText: pageText,
          debug: { 
            pageTitle: pageTitle, 
            bodyLength: bodyLength, 
            priceElExists: priceElExists, 
            priceSource: priceSource, 
            priceConfidence: priceConfidence, 
            allImgs: allImgs, 
            allPriceElements: allPriceElements,
            imgDebug: debugImgInfo.join(', ')
          }
        };
      })()`);
      
      // Log debug info to help diagnose extraction issues
      if (data.debug) {
        console.log(`    Debug: ${data.debug.bodyLength} chars, ${data.debug.allImgs} total imgs, price=$${data.price || 'null'}`);
      }
      
      // Use PRECISION IMAGE EXTRACTION for accurate vehicle photos
      let precisionImages: string[] = [];
      let imageQuality: 'excellent' | 'good' | 'fair' | 'poor' = 'poor';
      
      let hasVinMatchingImages = false;
      
      try {
        const extractionResult = await extractVehicleImages(page, data.vin, data.stockNumber);
        const { valid: validImages, suspicious, confidence, hasVinMatches, vinMatchCount } = validateImages(
          extractionResult.images,
          data.vin,
          data.stockNumber
        );
        
        hasVinMatchingImages = hasVinMatches;
        precisionImages = validImages.map(img => img.url);
        imageQuality = calculateImageQualityRating(precisionImages.length);
        
        console.log(`    Precision: ${precisionImages.length} valid, ${suspicious.length} filtered, VIN match: ${vinMatchCount} (${confidence})`);
        if (extractionResult.debug.gallerySelector) {
          console.log(`    Gallery: ${extractionResult.debug.gallerySelector} (${extractionResult.totalSlides} slides)`);
        }
        
        // If precision extraction returned zero valid images, fall back to legacy
        if (precisionImages.length === 0 && data.images.length > 0) {
          console.log(`    ⚠ No valid images after filtering, using legacy extraction`);
          precisionImages = data.images;
          hasVinMatchingImages = false;
        }
      } catch (precisionError) {
        console.log(`    ⚠ Precision extraction failed, using fallback: ${precisionError instanceof Error ? precisionError.message : String(precisionError)}`);
        precisionImages = data.images;
        imageQuality = calculateImageQualityRating(data.images.length);
      }
      
      // Detect badges and body type from page text
      const badges = detectBadges(data.pageText);
      const type = determineBodyType(data.pageText);
      
      // Calculate data quality score with actual VIN match data
      const dataQualityScore = calculateDataQualityScore({
        vin: data.vin,
        price: data.price,
        odometer: data.odometer,
        imageCount: precisionImages.length,
        descriptionLength: data.description?.length || 0,
        hasVinMatchingImages: hasVinMatchingImages
      });
      
      // Don't close the page - we're reusing it for all VDPs
      
      return {
        vin: data.vin,
        price: data.price,
        odometer: data.odometer,
        images: precisionImages.length > 0 ? precisionImages : data.images,
        trim: data.trim,
        description: data.description,
        badges,
        type,
        stockNumber: data.stockNumber,
        imageQuality,
        dataQualityScore
      };
    } catch (error) {
      console.log(`    ✗ VDP extraction error (attempt ${attempt + 1}): ${error instanceof Error ? error.message : String(error)}`);
      
      if (attempt < retries) {
        // Wait before retry with exponential backoff
        await new Promise(resolve => setTimeout(resolve, 2000 * (attempt + 1)));
        continue;
      }
      
      // Final attempt failed, return defaults
      console.log(`    ✗ VDP extraction failed after ${retries + 1} attempts`);
      return {
        vin: null,
        price: null,
        odometer: null,
        images: [],
        trim: 'Base',
        description: 'Used vehicle. Contact dealer for more information.',
        badges: [],
        type: 'SUV',
        stockNumber: null,
        imageQuality: 'poor' as const,
        dataQualityScore: 0
      };
    }
  }
  
  return {
    vin: null,
    price: null,
    odometer: null,
    images: [],
    trim: 'Base',
    description: 'Used vehicle. Contact dealer for more information.',
    badges: [],
    type: 'SUV',
    stockNumber: null,
    imageQuality: 'poor' as const,
    dataQualityScore: 0
  };
}

async function scrapeDealerListings(dealerConfig: typeof DEALER_CONFIGS[0]): Promise<DealerVehicleListing[]> {
  console.log(`\n[${dealerConfig.name}] Scraping dealer listing page...`);
  
  let chromiumPath = '';
  try {
    chromiumPath = execSync('which chromium').toString().trim();
  } catch {
    chromiumPath = '/nix/store/zi4f80l169xlmivz8vja8wlphq74qqk0-chromium-125.0.6422.141/bin/chromium';
  }

  // Get proxy if available
  const proxy = proxyManager.getNext();
  const launchOptions: any = {
    headless: true,
    executablePath: chromiumPath,
    args: [
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--disable-dev-shm-usage',
      '--disable-gpu',
      '--disable-blink-features=AutomationControlled'
    ],
  };

  // Add proxy args if configured
  if (proxy) {
    launchOptions.args.push(`--proxy-server=${proxy.server}`);
    console.log(`  Using proxy: ${proxy.server}`);
  }

  const browser = await puppeteer.launch(launchOptions);
  const page = await browser.newPage();
  
  // Authenticate proxy if needed
  if (proxy) {
    await proxyManager.authenticateProxy(page, proxy);
  }
  
  // Generate and apply random fingerprint
  const fingerprint = generateRandomFingerprint();
  await applyFingerprint(page, fingerprint);
  console.log(`  Applied fingerprint: ${fingerprint.viewport.width}x${fingerprint.viewport.height}`);
  
  // Try to load saved cookies
  const savedCookies = await cookieStore.loadCookies(dealerConfig.domain);
  if (savedCookies) {
    await page.setCookie(...savedCookies);
    console.log(`  ✓ Loaded saved cf_clearance cookies`);
  }
  
  // Add human-like delay before navigation
  await randomDelay(500, 1500);
  
  // Declare vehicles array outside try block so we can return partial results on error
  let vehicles: DealerVehicleListing[] = [];
  
  try {
    const response = await page.goto(dealerConfig.url, { waitUntil: 'domcontentloaded', timeout: 30000 });
    
    console.log(`  Waiting for vehicle listings to load...`);
    console.log(`  Response status: ${response?.status()}, url: ${response?.url()}`);
    
    // Check for Cloudflare challenge page
    const isChallenged = await isCloudflareChallenge(page);
    if (isChallenged) {
      console.log('  ⚠ Cloudflare challenge detected - waiting for automatic solve...');
      console.log('  This may take up to 60 seconds...');
      
      // Wait up to 60 seconds for Cloudflare challenge to resolve
      let attempts = 0;
      const maxAttempts = 60;
      
      while (attempts < maxAttempts) {
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // Check if challenge is solved by looking for vehicle content
        try {
          const hasVehicles = await page.evaluate(() => {
            return document.querySelectorAll('a[href*="/vehicles/2"]').length > 0;
          });
          
          if (hasVehicles) {
            console.log(`  ✓ Cloudflare challenge solved automatically after ${attempts + 1} seconds!`);
            
            // Save new cookies
            const cookies = await page.cookies();
            await cookieStore.saveCookies(dealerConfig.domain, cookies);
            break;
          }
        } catch (err) {
          // Continue waiting
        }
        
        // Also check if page content changed
        const stillChallenged = await isCloudflareChallenge(page);
        if (!stillChallenged) {
          console.log(`  ✓ Challenge page cleared after ${attempts + 1} seconds (checking for content...)`);
          await new Promise(resolve => setTimeout(resolve, 2000));
          break;
        }
        
        attempts++;
        
        if (attempts % 10 === 0) {
          console.log(`    Still waiting... (${attempts}/${maxAttempts}s)`);
        }
      }
      
      if (attempts >= maxAttempts) {
        // Save screenshot for debugging
        try {
          await page.screenshot({ path: '/tmp/cloudflare-blocked.png', fullPage: false });
          console.log('  Screenshot saved to /tmp/cloudflare-blocked.png');
        } catch (err) {
          // Ignore screenshot errors
        }
        throw new Error('Cloudflare challenge did not resolve after 60 seconds');
      }
    }
    
    // Human-like behavior: scroll before interacting
    await randomDelay(500, 1000);
    await humanLikeScroll(page);
    
    // Wait for vehicle links to appear with retry
    console.log('  Looking for vehicle listings...');
    let vehicleLinksFound = false;
    for (let retry = 0; retry < 3; retry++) {
      try {
        await page.waitForSelector('a[href*="/vehicles/2"]', { timeout: 10000 });
        vehicleLinksFound = true;
        console.log('  ✓ Vehicle listings loaded successfully');
        break;
      } catch (err) {
        console.log(`  Retry ${retry + 1}/3: Vehicle links not found yet...`);
        await randomDelay(2000, 3000);
      }
    }
    
    if (!vehicleLinksFound) {
      throw new Error('Vehicle listings failed to load after multiple retries');
    }
    
    // Give page a moment to fully render
    await page.waitForFunction(
      () => document.querySelectorAll('a[href*="/vehicles/2"]').length > 0,
      { timeout: 10000 }
    );

    // Infinite scroll to load ALL vehicles
    console.log(`  Scrolling to load all vehicles...`);
    let previousCount = 0;
    let stableCount = 0;
    
    for (let i = 0; i < 30; i++) { // Max 30 scrolls
      // Scroll to bottom
      await page.evaluate(() => {
        window.scrollTo(0, document.body.scrollHeight);
      });
      
      // Wait for new content to load
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Check if new vehicles loaded
      const currentCount = await page.evaluate(() => {
        return document.querySelectorAll('a[href*="/vehicles/2"]').length;
      });
      
      console.log(`    Scroll ${i + 1}: Found ${currentCount} vehicle links`);
      
      if (currentCount === previousCount) {
        stableCount++;
        if (stableCount >= 3) {
          console.log(`    ✓ No new vehicles after 3 scrolls, stopping.`);
          break;
        }
      } else {
        stableCount = 0;
      }
      
      previousCount = currentCount;
    }

    console.log(`  Extracting VDP URLs...`);
    
    const vdpUrls = await page.evaluate(function(baseUrl) {
      var results = [];
      var processedUrls = {};
      
      // Find all vehicle detail page links
      var links = document.querySelectorAll('a[href*="/vehicles/2"]');
      
      for (var i = 0; i < links.length; i++) {
        var link = links[i];
        var href = link.getAttribute('href');
        if (!href) continue;
        
        // Filter for actual VDP URLs: /vehicles/{year}/{make}/{model}/{city}/{province}/{ID}/
        var match = href.match(/\/vehicles\/(\d{4})\/([a-z-]+)\/([a-z0-9-]+)\/([a-z-]+)\/([a-z]+)\/(\d+)\//i);
        if (!match) continue;
        
        var fullUrl = href.indexOf('http') === 0 ? href : 'https://' + baseUrl + href;
        
        if (processedUrls[fullUrl]) continue;
        processedUrls[fullUrl] = true;
        
        // Extract year, make, model from URL
        var year = parseInt(match[1]);
        var makeParts = match[2].split('-');
        var make = '';
        for (var j = 0; j < makeParts.length; j++) {
          if (j > 0) make += ' ';
          make += makeParts[j].charAt(0).toUpperCase() + makeParts[j].slice(1);
        }
        var modelParts = match[3].split('-');
        var model = '';
        for (var k = 0; k < modelParts.length; k++) {
          if (k > 0) model += ' ';
          model += modelParts[k].charAt(0).toUpperCase() + modelParts[k].slice(1);
        }
        
        results.push({ vdpUrl: fullUrl, year: year, make: make, model: model });
      }
      
      return results;
    }, dealerConfig.domain);

    console.log(`  ✓ Found ${vdpUrls.length} VDP URLs, now extracting VIN/price/odometer...`);
    
    // Visit each VDP to extract complete vehicle data (vehicles array declared outside try block)
    
    // Track current page - will be refreshed periodically to prevent detached frame errors
    let currentVdpPage = page;
    
    // Initialize backup cookies from the page that already passed Cloudflare
    let savedCookiesBackup: any[] = [];
    try {
      savedCookiesBackup = await page.cookies();
      console.log(`  ✓ Initialized cookie backup with ${savedCookiesBackup.length} cookies`);
    } catch (e) {
      console.log(`  ⚠ Could not get initial cookies for backup`);
    }
    const PAGE_REFRESH_INTERVAL = 5; // REDUCED from 10 to 5 for more stability
    
    console.log(`  Processing ${vdpUrls.length} vehicles (refreshing page every ${PAGE_REFRESH_INTERVAL} vehicles)...`);
    
    // Helper function to safely refresh the page
    async function refreshPage(reason: string): Promise<void> {
      console.log(`    🔄 ${reason}`);
      
      // Try to get cookies from current page, use backup if failed
      let cookiesToRestore = savedCookiesBackup;
      try {
        cookiesToRestore = await currentVdpPage.cookies();
        savedCookiesBackup = cookiesToRestore; // Update backup
      } catch (e) {
        console.log(`    ⚠ Could not get cookies from current page, using backup (${savedCookiesBackup.length} cookies)`);
      }
      
      // Close old page (ignore errors if already closed)
      try {
        await currentVdpPage.close();
      } catch (e) {
        // Page may already be closed
      }
      
      // Create fresh page
      currentVdpPage = await browser.newPage();
      
      // Restore cookies and fingerprint
      if (cookiesToRestore.length > 0) {
        await currentVdpPage.setCookie(...cookiesToRestore);
      }
      await applyFingerprint(currentVdpPage, fingerprint);
      
      console.log(`    ✓ Page refreshed with ${cookiesToRestore.length} cookies preserved`);
    }
    
    for (let i = 0; i < vdpUrls.length; i++) {
      const urlData = vdpUrls[i];
      console.log(`  [${i + 1}/${vdpUrls.length}] Scraping ${urlData.year} ${urlData.make} ${urlData.model}...`);
      
      // Refresh page every PAGE_REFRESH_INTERVAL vehicles to prevent frame detachment
      if (i > 0 && i % PAGE_REFRESH_INTERVAL === 0) {
        await refreshPage(`Preventive refresh (processed ${i} vehicles)...`);
      }
      
      // Pass the current page with frame detachment recovery
      let detailData: VehicleDetailData;
      try {
        detailData = await scrapeVehicleDetailPage(currentVdpPage, urlData.vdpUrl);
        
        // If scrape returned empty (all retries failed), try emergency refresh
        if (!detailData.price && detailData.images.length === 0 && !detailData.vin) {
          console.log(`    ⚠ Empty result - attempting emergency page refresh...`);
          await refreshPage('Emergency recovery from failed scrape');
          detailData = await scrapeVehicleDetailPage(currentVdpPage, urlData.vdpUrl);
        }
      } catch (pageError: any) {
        // Detect frame detachment and recover
        if (pageError?.message?.includes('detached') || pageError?.message?.includes('Session closed')) {
          console.log(`    ⚠ Frame detachment detected - emergency page refresh...`);
          await refreshPage('Emergency recovery from frame detachment');
          detailData = await scrapeVehicleDetailPage(currentVdpPage, urlData.vdpUrl);
        } else {
          throw pageError;
        }
      }
      
      vehicles.push({
        vin: detailData.vin,
        year: urlData.year,
        make: urlData.make,
        model: urlData.model,
        trim: detailData.trim,
        odometer: detailData.odometer,
        price: detailData.price,
        images: detailData.images,
        description: detailData.description,
        badges: detailData.badges,
        type: detailData.type,
        stockNumber: detailData.stockNumber,
        vdpUrl: urlData.vdpUrl,
        dealershipId: dealerConfig.dealershipId,
        dealershipName: dealerConfig.name,
        location: dealerConfig.location,
        imageQuality: detailData.imageQuality,
        dataQualityScore: detailData.dataQualityScore,
      });
      
      console.log(`    ✓ ${detailData.images.length} photos (${detailData.imageQuality}), Quality: ${detailData.dataQualityScore}/100, Price: $${detailData.price || 'N/A'}`);
      
      // Human-like delay between requests (randomized)
      await randomDelay(800, 1500);
    }
    
    console.log(`  ✓ Successfully scraped ${vehicles.length} vehicles from ${dealerConfig.name}`);
    
    // Clean up (vdpPage is the same as page, just close the browser)
    try {
      await browser.close();
    } catch (e) {
      // Browser may already be closed
    }
    return vehicles;
    
  } catch (error) {
    console.error(`  ✗ Error scraping ${dealerConfig.name}:`, error);
    
    // IMPORTANT: Return partial results if we have any
    // This prevents losing 25+ successfully scraped vehicles if the browser crashes
    if (vehicles && vehicles.length > 0) {
      console.log(`  ⚠ Returning ${vehicles.length} partial results despite error`);
      try {
        await browser.close();
      } catch (e) {
        // Browser may already be closed
      }
      return vehicles;
    }
    
    try {
      await browser.close();
    } catch (e) {
      // Browser may already be closed
    }
    return [];
  }
}

export async function scrapeAllDealerListings(): Promise<DealerVehicleListing[]> {
  console.log('\n=== SCRAPING DEALER LISTING PAGES ===');
  
  const allListings: DealerVehicleListing[] = [];
  
  for (const config of DEALER_CONFIGS) {
    try {
      const listings = await scrapeDealerListings(config);
      allListings.push(...listings);
    } catch (error) {
      console.error(`Failed to scrape ${config.name}:`, error);
    }
  }
  
  console.log(`\n✓ Total dealer listings scraped: ${allListings.length}\n`);
  
  return allListings;
}
